from django.shortcuts import render

# Create your views here.

def home(request):
    return render(request,'core\index.html')

def cadastroCliente(request):
    return render(request, 'cadastro_cliente\cadastro_cliente.html')

def cadastroVeiculo(request):
    return render(request, 'cadastro_veiculo\cadastro_veiculo.html')

def listaCliente(request):
    return render(request, 'lista_cliente\lista_cliente.html')

def listagemVeiculo(request):
    return render(request, 'listagem_veiculos\listagem_veiculo.html')

def tabela(request):
    return render(request, 'tabela\\tabela.html')

def cadastroTabela(request):
    return render(request, 'cadastro_tabela\cadastro_tabela.html')