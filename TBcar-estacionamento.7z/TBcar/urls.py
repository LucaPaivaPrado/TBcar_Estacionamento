"""TBcar URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from core.views import home
from core.views import cadastroCliente
from core.views import cadastroVeiculo
from core.views import listaCliente
from core.views import listagemVeiculo
from core.views import tabela
from core.views import cadastroTabela


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='url_principal'),
    path('cadastroCliente/', cadastroCliente, name='url_cadastro_cliente'),
    path('cadastroVeiculo/', cadastroVeiculo, name='url_cadastro_veiculo'),
    path('listaCliente/', listaCliente, name='url_lista_cliente'),
    path('listagemVeiculo/', listagemVeiculo, name='url_listagem_veiculo'),
    path('tabela/', tabela, name='url_tabela'),
    path('cadastroTabela/', cadastroTabela, name='url_cadastro_tabela'),

]
